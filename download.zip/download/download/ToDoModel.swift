class ToDo{
    var userId = 0
    var id = 0
    var title = ""
    var completed = false
}

class ToDoModel{
    var todos = [ToDo]()
}
